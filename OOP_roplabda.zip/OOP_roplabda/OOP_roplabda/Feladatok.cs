﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_roplabda
{
    class Feladatok
    {
        public static List<Csapat> csapatok = new List<Csapat>();
        public static void CsapatokBekerese()
        {
            string Csapatnev;
            do
            {
                Console.Write("Kérlek add meg a csapatok nevét, a \"0\" karakterrel léphetsz tovább: ");
                Csapatnev = Console.ReadLine();
                if(Csapatnev!="0") csapatok.Add(new Csapat(Csapatnev));
            } while (Csapatnev!="0");
            Console.Clear();
            csapatok = EllenfelekHozzáadása(csapatok);
        }

        private static List<Csapat> EllenfelekHozzáadása(List<Csapat> csapatok)
        {
            for (int i = 0; i < csapatok.Count; i++)
            {
                csapatok = EllenfelekHozzáadásaLepteto(csapatok,i);
            }
            return csapatok;
        }

        private static List<Csapat> EllenfelekHozzáadásaLepteto(List<Csapat> csapatok, int i)
        {
            for (int j = 0; j < csapatok.Count; j++)
            {
                if (csapatok[i].CsapatNev != csapatok[j].CsapatNev)
                    csapatok[i].MegmaradtEllenfelek.Add(csapatok[j].CsapatNev);
            }
            return csapatok;
        }

        public static void Players()
        {
            for (int i = 0; i < csapatok.Count; i++) JatekosHozzaadas(i);
        }

        private static void JatekosHozzaadas(int i)
        {
            string nev="";
            do
            {
                Console.Write($"Kérlek add meg a {csapatok[i].CsapatNev} csapat " +
                    $"{csapatok[i].Jatekosok.Count + 1}.játékosának nevét: ");
                nev = Console.ReadLine();
                if (nev != "0") csapatok[i].JatekosokFrissit(nev); ;
            } while (nev!="0");
            Console.Clear();
        }

        public static void Menu()
        {
            Console.Write("\n\"1\".csapat hozzáadás\n\"2\".játékos hozzáadás\n\"3\".Liga indítása\n\"4\".Pontok külön hozzáadása\nKérel add meg hogy mit szeretnél indítani: ");
            int response = Convert.ToInt32(Console.ReadLine());
            Atiranyitas(response);
        }

        private static void Atiranyitas(int response)
        {
            switch (response)
            {
                case 1:
                    CsapatokBekerese();
                    Menu();
                    break;
                case 2:
                    Players();
                    Menu();
                    break;
                case 3:
                    LigaIndito();
                    Menu();
                    break;
                case 4:
                    Pontok();
                    Menu();
                    break;
            }
        }

        private static void LigaIndito()
        {
            int meccsekszama = csapatok.Count * (csapatok.Count - 1) / 2;
            for (int i = 0; i < meccsekszama; i++)
            {
                //csapatok random indítása egymás ellen
            }
        }

        private static void Pontok()
        {
            Console.Write($"Kérlek add meg a csapatnevét akinek pontot akarsz adni: ");
            string nev = Console.ReadLine();
            for (int i = 0; i < csapatok.Count; i++)
            {
                if (csapatok[i].CsapatNev == nev)
                {
                    Console.Write("Add meg a hozzáadandó pont mennyiségét: ");
                    int pont = Convert.ToInt32(Console.ReadLine());
                    csapatok[i].PontAdd(pont);
                    break;
                } 
            }
            Console.Clear();
        }
    }
}
