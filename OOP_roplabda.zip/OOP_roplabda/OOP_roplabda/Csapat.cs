﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_roplabda
{
    class Csapat
    {
        public string CsapatNev { get; set; }
        public List<string> Jatekosok { get; set; }
        public int OsszesPont { get; set; }
        public int VegHelyezes { get; set; }
        public List<string> MegmaradtEllenfelek { get; set; }

        public Csapat(string CsapatNev)
        {
            this.CsapatNev = CsapatNev;
            Jatekosok = new List<string>();
            OsszesPont = 0;
            MegmaradtEllenfelek = new List<string>();
        }

        public void JatekosokFrissit(string nev)
        {
            Jatekosok.Add(nev);
        } 

        public void PontAdd(int pontok)
        {
            OsszesPont += pontok;
        }
    }
}
