﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_roplabda
{
    class Program
    {
        static void Main(string[] args)
        {
            Feladatok.CsapatokBekerese();
            Feladatok.Players();
            Feladatok.Menu();
            Console.ReadKey();
        }
    }
}
